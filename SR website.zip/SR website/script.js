// Smooth scrolling for internal links
document.querySelectorAll('a[href^="tel:"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        // You could add smooth scrolling functionality here if needed
        // Currently, the browser's default behavior will handle the call
    });
});

// Hover effects for images (Optional if CSS handles it)
document.querySelectorAll('.quote-image img').forEach(image => {
    image.addEventListener('mouseover', function() {
        // Additional JavaScript-based hover effects could be added here
        console.log('Image hovered');
    });

    image.addEventListener('mouseout', function() {
        // Additional JavaScript-based hover effects could be added here
        console.log('Image hover ended');
    });
});

// Example: Alert when clicking the contact phone link
document.querySelector('.contact a[href^="tel:"]').addEventListener('click', function(e) {
    alert("You are about to call SR Xerox at 8489413570");
});
