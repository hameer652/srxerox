// SR XEROX App - React Component
// Your full App code should go here.
